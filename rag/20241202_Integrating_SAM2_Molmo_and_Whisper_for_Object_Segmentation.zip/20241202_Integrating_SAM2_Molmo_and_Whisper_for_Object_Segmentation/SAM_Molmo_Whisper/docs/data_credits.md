# README

## Data

* `demo_data/`
  * `image_2.jpg`: Photo by Huy Phan: https://www.pexels.com/photo/high-angle-photography-of-two-person-walking-beside-road-1383782/
    * https://www.pexels.com/photo/high-angle-photography-of-two-person-walking-beside-road-1383782/
  * `image_3.jpg`: Photo by Lina Kivaka: https://www.pexels.com/photo/people-walking-near-trees-2253911/
    * https://www.pexels.com/photo/people-walking-near-trees-2253911/
  * `image_5.jpg`: Photo by Sergio Zhukov: https://www.pexels.com/photo/two-ducks-swimming-among-autumn-leaves-28672757/
    * https://www.pexels.com/photo/two-ducks-swimming-among-autumn-leaves-28672757/
  * `image_6.jpg`: Photo by RITESH SINGH: https://www.pexels.com/photo/tourist-taking-a-picture-of-a-blue-dodge-challenger-16433691/
    * https://www.pexels.com/photo/tourist-taking-a-picture-of-a-blue-dodge-challenger-16433691/
  * `image_7.jpg`: Photo by Jeffry Surianto: https://www.pexels.com/photo/vibrant-birds-hovering-near-purple-flowers-28822457/
    * https://www.pexels.com/photo/vibrant-birds-hovering-near-purple-flowers-28822457/
  * `image_8.jpg`: Photo by Filipe de Azevedo: https://www.pexels.com/photo/photo-of-people-walking-on-a-pedestrian-lane-4937603/
    * https://www.pexels.com/photo/photo-of-people-walking-on-a-pedestrian-lane-4937603/
  * `image_9.jpg`: https://www.pexels.com/photo/woman-in-dress-standing-with-bag-in-black-and-white-27091195/
  * `image_10.jpg`: Photo by Lisa Fotios: https://www.pexels.com/photo/variety-of-fruits-on-white-ceramic-bowl-with-gray-fork-1170371/
    * https://www.pexels.com/photo/variety-of-fruits-on-white-ceramic-bowl-with-gray-fork-1170371/
  * `image_11.jpg`: Photo by SOO CHUL PARK: https://www.pexels.com/photo/dogs-sitting-on-sofa-on-a-terrace-19216490/
    * https://www.pexels.com/photo/dogs-sitting-on-sofa-on-a-terrace-19216490/
  * 